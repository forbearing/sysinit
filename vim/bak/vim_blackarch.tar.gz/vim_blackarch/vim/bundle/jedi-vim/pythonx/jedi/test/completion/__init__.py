""" needed for some modules to test against packages. """

some_variable = 1


from . import imports
#? int()
imports.relative()
